/** ----------------------------------------------------------------------------
Minicurso: Implementação de geração de colunas usando CPLEX em linguagem C/C++
Descricao: geracao de colunas para o problema de corte unidimensional (PCU)
Autores: Landir Saviniec e Luiz Henrique Cherri
-----------------------------------------------------------------------------**/

#include <iostream>
#include <vector>
#include <pthread.h>
#include <ilcplex/ilocplex.h>

int N_PEDIDOS;
double COMP_FIXO;
std::vector<double> CompPedido;
std::vector<double> Demanda;

class Subproblema;
class Mestre;

class Modelo
{
    public:
        IloEnv env;
        IloModel model;
        IloCplex cplex;
        IloObjective objective;

        //construtores
        Modelo(){
            env = IloEnv();
            model = IloModel(env);
            cplex = IloCplex(env);
        }

        ~Modelo(){
            model.end();
            cplex.end();
            env.end();
        }

        //metodos
        void setStream(std::ostream& st){
            cplex.setOut(st);
        }

        void setStreamOff(){
            cplex.setOut(env.getNullStream());
        }

        void solve(){
            cplex.solve();
        }

        IloNum getObjective(){
            return cplex.getObjValue();
        }

        IloCplex::CplexStatus getStatus(){
            return this->cplex.getCplexStatus();
        }
};

class Mestre : public Modelo
{
    public:

        IloNumVarArray X;   //variaveis X
        IloNumArray Coef;   //coeficientes de X
        IloRangeArray Range1;

        //construtores
        Mestre(){
            this->objective = IloMinimize(this->env);

            this->criar_modelo();

            this->model.add(this->objective);
            this->cplex.extract(this->model);
        }

        ~Mestre(){}

        //metodos
        void criar_modelo(){

            //criar array de variaveis e coeficientes
            X = IloNumVarArray(this->env);
            Coef = IloNumArray(this->env);

            //cria Range1
            Range1 = IloRangeArray(this->env, N_PEDIDOS);
            for(auto i=0; i<N_PEDIDOS; i++){
                Range1[i] = IloRange(this->env, Demanda[i], IloInfinity);
            }
            this->model.add(Range1);
        }

        void adicionar_coluna(Subproblema* sub);

        void criar_colunas_artificiais(){
            const double BIGM = 1.0;

            for(auto i=0; i<N_PEDIDOS; i++){
                IloNumColumn newCol = this->objective(BIGM);
                Coef.add(BIGM);

                //Range1
                newCol += Range1[i](int(COMP_FIXO / CompPedido[i]));

                IloNumVar newVar(newCol, 0.0, IloInfinity);
                this->model.add(newVar);
                X.add(newVar);
            }
        }

        void converter_x_para_inteiro(){

            for(auto i=0; i<X.getSize(); i++){
                this->model.add(IloConversion(this->env, X[i], ILOINT));
            }
        }

        void imprimir_solucao(){

            std::cout << "\nCortes:" << std::endl;
            for(auto i=0; i<X.getSize(); i++){
                std::cout << "X[" << i << "] = " << this->cplex.getValue(X[i]) << std::endl;
            }
        }
};

class Subproblema : public Modelo
{
	public:

        IloNumVarArray Y;

        //construtores
        Subproblema(){
            this->objective = IloMinimize(this->env);

            this->criar_modelo();

            this->model.add(this->objective);
            this->cplex.extract(this->model);
        }

        ~Subproblema(){}

        //metodos
        void criar_modelo(){

            //define as variaveis do modelo
            Y = IloNumVarArray(this->env, N_PEDIDOS);

            for(auto i=0; i<N_PEDIDOS; i++){
                Y[i] = IloNumVar(this->env, 0, IloInfinity, ILOINT);
            }

            //define as restricoes
            IloExpr expr(this->env);
            for(auto i=0; i<N_PEDIDOS; i++){
                expr += CompPedido[i] * Y[i];
            }
            this->model.add(expr <= COMP_FIXO);
        }

        void update_objective(Mestre* mestre){
            //seta os coeficientes das variaveis
            for(auto i=0; i<N_PEDIDOS; i++){
                double dual = mestre->cplex.getDual(mestre->Range1[i]);
                this->objective.setLinearCoef(Y[i], -dual);
            }
            this->objective.setConstant(1.0);
        }

        double get_num_barras(int i){
            //retorna numero de barras do tipo i
            return this->cplex.getValue(Y[i]);
        }
};

void Mestre::adicionar_coluna(Subproblema* sub){

    const double custo = 1.0;
    IloNumColumn newCol = this->objective(custo);
    Coef.add(custo);

    //Range1
    for(auto i=0; i<N_PEDIDOS; i++){
        newCol += Range1[i](sub->get_num_barras(i));
    }

    IloNumVar newVar(newCol, 0.0, IloInfinity);
    this->model.add(newVar);
    X.add(newVar);
}

void ler_dados(std::string arquivo){

    std::ifstream in(arquivo.c_str());

    in >> N_PEDIDOS;
    std::cout << "Numero de pedidos: " << N_PEDIDOS << std::endl;

    in >> COMP_FIXO;
    std::cout << "L: " << COMP_FIXO << std::endl;

    double aux;

    std::cout << "Comprimento dos pedidos:" << std::endl;
    for(auto i=0; i<N_PEDIDOS; i++){
        in >> aux;
        CompPedido.push_back(aux);
        std::cout << " " << CompPedido[i];
    }

    std::cout << "\nDemanda:" << std::endl;
    for(auto i=0; i<N_PEDIDOS; i++){
        in >> aux;
        Demanda.push_back(aux);
        std::cout << " " << Demanda[i];
    }

    std::cout << std::endl;
}

int main(int argc, char* argv[]){

    if(argc != 2){
        std::cout << "Argumento invalido." << std::endl;
        return 0;
    }

    ler_dados(argv[1]);

    std::cout << "\n== Geracao de colunas ==============\n" << std::endl;

    //criar o subproblema
    Subproblema sub;
    sub.setStreamOff();

    //criar o mestre
    Mestre mestre;
    mestre.setStreamOff();
    mestre.criar_colunas_artificiais();

    //algoritmo de geracao de colunas
    const double EPS = 1.0e-5;
    double custoSub;
    int novaColuna = 0;
    int iter = 0;

    do{

        iter++;
        std::cout << "Iteracao " << iter << std::endl;

        mestre.solve();
        std::cout << std::setprecision(10) << "mestre = " << mestre.getObjective() << std::endl;

        novaColuna = 0;

        sub.update_objective(&mestre);
        sub.solve();

        custoSub = std::min(sub.getObjective(), 0.0);

        if(custoSub < -EPS){
            mestre.adicionar_coluna(&sub);
            novaColuna++;
            std::cout << std::setprecision(10) << "sub = " << custoSub << std::endl;
        }

        std::cout << std::endl;
    }while(novaColuna > 0);

    double gc = mestre.getObjective();
	
	//converte as variaveis para inteiro e resolve 
    mestre.converter_x_para_inteiro();
    mestre.setStream(std::cout);
    mestre.solve();

    std::cout << "\n== Resultado ==================" << std::endl;
    std::cout << std::setprecision(10) << "GC = " << gc << std::endl;
    std::cout << std::setprecision(10) << "Sol = " << mestre.getObjective() << std::endl;
    mestre.imprimir_solucao();

    return 0;
}
