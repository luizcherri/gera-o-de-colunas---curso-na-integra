#include <iostream>
#include <vector>
#include <ilcplex/ilocplex.h>
class Mestre;
class Subproblema;

//estrutura de dados
int N_PEDIDOS;  //|B|
double COMP_FIXO;   //L
std::vector<double> CompPedido;  //l_i
std::vector<double> Demanda;  //d_i

class Modelo
{
    public:

        IloEnv env;
        IloModel model;
        IloCplex cplex;
        IloObjective objective;

        Modelo(){
//            std::cout << "Modelo inicializado" << std::endl;
            env = IloEnv();
            model = IloModel(env);
            cplex = IloCplex(env);
        }

        ~Modelo(){
//            std::cout << "Modelo destruido" << std::endl;
            model.end();
            cplex.end();
            env.end();
        }

        void solve(){
            cplex.solve();
//            std::cout << "cplex foi envocado" << std::endl;
        }

        IloNum getObjective(){
            return cplex.getObjValue();
        }

        void setStreamOff(){
            cplex.setOut(env.getNullStream());
        }
};

class Mestre : public Modelo
{
    public:

    IloNumVarArray X;   //variaveis das colunas
    IloNumArray Coef;   //coef das variaveis das colunas
    IloRangeArray Range1;

    Mestre(){
        objective = IloMinimize(env);

        criar_modelo();

        model.add(objective);
        cplex.extract(model);
    }

    ~Mestre(){

    }

    void criar_modelo(){
        //cria array de variaveis e coef
        X = IloNumVarArray(env);
        Coef = IloNumArray(env);

        //cria Range1
        Range1 = IloRangeArray(env, N_PEDIDOS);
        for(auto i=0; i<N_PEDIDOS; i++){
            Range1[i] = IloRange(env, Demanda[i], IloInfinity);
        }
        model.add(Range1);
    }

    void criar_colunas_artificiais(){
        const double BIGM = 1.0;

        //Range1
        for(auto i=0; i<N_PEDIDOS; i++){
            IloNumColumn newCol = objective(BIGM);
            Coef.add(BIGM);

//            newCol += Range1[i](1.0);
            newCol += Range1[i]( int(COMP_FIXO / CompPedido[i]) );

            IloNumVar newVar(newCol, 0.0, IloInfinity);
            model.add(newVar);
            X.add(newVar);
        }
    }

    void adicionar_coluna(Subproblema* sub);

    void imprimir_solucao(){

        std::cout << "\nCortes:" << std::endl;
        for(auto i=0; i < X.getSize(); i++){
            std::cout << "X[" << i << "] = "
                        << cplex.getValue(X[i]) << std::endl;
        }
    }

    void converter_x_para_inteiro(){

        for(auto i=0; i < X.getSize(); i++){
            model.add( IloConversion(env, X[i], ILOINT) );
        }
    }
};

class Subproblema : public Modelo
{
    public:

    IloNumVarArray Y;
    int i;  //variavel para identificar o  indice do subproblema

    Subproblema(int index){
        i = index;
        objective = IloMinimize(env);

        criar_modelo();

        model.add(objective);
        cplex.extract(model);
    }

    ~Subproblema(){

    }

    void criar_modelo(){
        //define as variaveis
        Y = IloNumVarArray(env, N_PEDIDOS);
        for(auto i=0; i<N_PEDIDOS; i++){
            Y[i] = IloNumVar(env, 0, IloInfinity, ILOINT);
        }

        //define as restricoes
        IloExpr expr(env);
        for(auto i=0; i<N_PEDIDOS; i++){
            expr += CompPedido[i] * Y[i];
        }
        model.add(expr <= COMP_FIXO);
    }

    void update_objective(Mestre* mestre){
        //seta os coef das variaveis do subproblema
        for(auto i=0; i<N_PEDIDOS; i++){
            double dual = mestre->cplex.getDual(mestre->Range1[i]);
            objective.setLinearCoef(Y[i], -dual);
        }
        objective.setConstant(1.0);
    }

    double get_num_barras(int i){
        return cplex.getValue(Y[i]);
    }
};

void Mestre::adicionar_coluna(Subproblema* sub){
    const double custo = 1.0;

    IloNumColumn newCol = objective(custo);
    Coef.add(custo);

    //Range1
    for(auto i=0; i<N_PEDIDOS; i++){
        newCol += Range1[i](sub->get_num_barras(i));
    }

    IloNumVar newVar(newCol, 0.0, IloInfinity);
    model.add(newVar);
    X.add(newVar);
}

void ler_dados(std::string arquivo){

    std::ifstream in(arquivo.c_str());

    in >> N_PEDIDOS;
    std::cout << "Numero de pedidos: " << N_PEDIDOS << std::endl;

    in >> COMP_FIXO;
    std::cout << "L: " << COMP_FIXO << std::endl;

    double aux;

    std::cout << "Comprimento dos pedidos:" << std::endl;
    for(auto i=0; i<N_PEDIDOS; i++){
        in >> aux;
        CompPedido.push_back(aux);
        std::cout << " " << CompPedido[i];
    }

    std::cout << "\nDemanda:" << std::endl;
    for(auto i=0; i<N_PEDIDOS; i++){
        in >> aux;
        Demanda.push_back(aux);
        std::cout << " " << Demanda[i];
    }

    std::cout << std::endl;
}

int main(int argc, char* argv[]){

    ler_dados("instancia3.dat");
    int N_SUB = 1;

    //criar o mestre
    Mestre mestre;
    mestre.setStreamOff();
    mestre.criar_colunas_artificiais();

    //criar os subproblemas
    std::vector<Subproblema*> Sub;
    for(auto i=0; i<N_SUB; i++){
        Subproblema* sub = new Subproblema(i);
        sub->setStreamOff();
        Sub.push_back(sub);
    }

    //algoritmo de geracao de colunas
    int novaColuna = 0;
    std::vector<double> custoSub(N_SUB, 0.0);
    const double EPS = 1.0e-5;
    int iter = 0;

    do{

        iter++;
        std::cout << "\nIteracao " << iter << std::endl;

        //resolver o mestre
        mestre.solve();
        std::cout << std::setprecision(10) << "Mestre = " << mestre.getObjective() << std::endl;

        novaColuna = 0;
        //resolver os subproblemas

        for(auto i=0; i<N_SUB; i++){
            Sub[i]->update_objective(&mestre);
            Sub[i]->solve();
            custoSub[i] = Sub[i]->getObjective();
        }

        for(auto i=0; i<N_SUB; i++){
            if(custoSub[i] < -EPS){
                mestre.adicionar_coluna(Sub[i]);
                novaColuna++;
            }
        }
    }while(novaColuna > 0);

    double gc = mestre.getObjective();
    mestre.imprimir_solucao();

    mestre.converter_x_para_inteiro();
    mestre.solve();
    mestre.imprimir_solucao();

    double sol = mestre.getObjective();
    std::cout << std::setprecision(10) << "GC = " << gc << std::endl;
    std::cout << std::setprecision(10) << "sol = " << sol << std::endl;

    double gap = 100 * ((sol - gc) / sol);
    std::cout << std::setprecision(10) << "Gap = " << gap << std::endl;

    for(auto i=0; i<N_SUB; i++){
        delete Sub[i];
    }

    getchar();
}
